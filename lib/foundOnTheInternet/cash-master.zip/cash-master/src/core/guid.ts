
// @require ./cash.ts

let guid = 1;

interface CashStatic {
  guid: number;
}

cash.guid = guid;
