
const dataNamespace = '__cashData',
      dataAttributeRe = /^data-(.*)/;
