
const cssVariableRe = /^--/;
