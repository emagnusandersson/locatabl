---
name: Bug report
about: Create a report to help us improve
---

<!-- Please search existing issues to avoid creating duplicates -->

### Current behavior

<!-- Describe how to reproduce the issue -->

### Expected behavior

<!-- Describe what is the expected behavior -->
