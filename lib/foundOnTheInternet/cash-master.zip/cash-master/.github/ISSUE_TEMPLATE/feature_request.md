---
name: Feature request
about: Suggest an idea for this project
---

<!-- Please search existing issues to avoid creating duplicates -->

### Feature description

<!-- Describe the feature you'd like -->

### Feature motivation

<!-- Why do you want this? -->

Is this feature present in jQuery? Yes/No
